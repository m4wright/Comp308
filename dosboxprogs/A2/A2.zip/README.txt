These programs were developed and tested using DOSBOX.

